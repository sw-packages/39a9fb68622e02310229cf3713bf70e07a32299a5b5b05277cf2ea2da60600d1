// Protocol Buffers - Google's data interchange format
// Copyright 2016 Google Inc.  All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

// This one file in the chain tests is compiled by itself to ensure if was
// generated with the extra #imports needed to pull in the indirect Root class
// used in its Root registry.
#import "objectivec/Tests/UnittestExtensionChainF.pbobjc.m"
